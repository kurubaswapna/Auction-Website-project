import { useState } from 'react'
import './Style.css'

function Signup() {
  
  return (
    <>

    <form>
      <input type="text" placeholder="Enter your name" />
      <input type="text" placeholder="Enter your email" />
      <input type="password" placeholder="Enter your password" />
      <input type="password" placeholder="Confirm your password" />
      <button type="submit">SignUp</button> {/* Add a submit button */}
    </form>
    
    </>
  )
}

export default Signup