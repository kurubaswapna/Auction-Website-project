import { useState } from 'react'
import './Style.css'

function Dashboard() {
  
  return (
    <>

<div class="card" >
  <img src="https://img.freepik.com/free-vector/antique-auction-isometric-composition_1284-22062.jpg?semt=ais_hybrid" class="card-img-top" alt="..."/>
  <div class="card-body">
    <h5 class="card-title">Card title</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    <a href="#" class="btn btn-primary">Go somewhere</a>
  </div>
</div>
    
    </>
  )
}

export default Dashboard