import { useState } from 'react'
import './App.css'

function App() {
  
  return (
    <>

    <h1 className='txtcolor'>Hello world</h1>
    <p className='txtcolor2'>Auction Platform</p>
    </>
  )
}

export default App
